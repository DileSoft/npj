<?php

$text = $this->Format($what, "wacko");
$text = $this->Format($text, "post_links");

print($text);


?>
