<?php
  return include( $dir."/recentchanges.php" );
?>
