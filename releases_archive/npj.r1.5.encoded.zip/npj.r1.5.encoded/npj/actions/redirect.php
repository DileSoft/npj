<?php
//  {{Redirect to="kuso@npj:todo" absolute=1 }}

  $params["immediate"] = 1;
  return include( $dir."/goto.php" );
?>
