<?php

// {{search [for="WackoWiki"] [style="br|ol|ul"] [topic|title="1"] [form="1"] 
//         [order="relevance|tag|subject"] }}
//
//  $debug->Trace_R( $params );
//  $debug->Error( $script_name );
  $rh->UseClass( "ListObject", $rh->core_dir );

  if ($_REQUEST["_where"]) $params["where"]="node";

  $templates = array( "br", "ul", "ol", "context" );
  if (!isset($params["style"])) $params["style"] = "ul";
  if (!$params[0]) $form=1;//$params[0] = $this->npj_object_address;
  $search = $params[0];

  if ($params["order"] == "tag") $order = "tag ASC"; else
  if ($params["order"] == "subject") { $params["subject"]=1; $order = "subject ASC"; } else
  $order = "relev DESC";

  if ($params["where"] == "node") $where = ""; else
  {
   $data = &$this->Load(2);
   $where = " AND r.user_id=".$db->Quote($data["user_id"]);
  }

  if ($params["topic"] == "1" || $params["title"] == "1") $title=1;
  if ($_REQUEST["_topic"] == "on") $title=1;

  if ($_REQUEST["_phrase"]) $phrase=$_REQUEST["_phrase"];
  if (!$search && $phrase) $search=$phrase;

  if ($params["form"] == "1") $form=1;

  if ($search) 
  {
   // 0. check if we can use "IN BOOLEAN MODE"
   $rs = $db->Execute("SELECT VERSION() as v");
   if ($rs->fields["v"]{0}=="4") $extended = true;
   else $extended = false;

   // 1. compose & run sql
   $sql = "SELECT r.edited_user_name, r.edited_user_login, r.edited_user_node_id, ".
          "r.type, r.record_id as id, r.record_id, r.subject, r.tag, r.supertag, r.user_id, r.version_tag, r.user_id, ".
          "r.type, ".($title?"1":"match(body) against (".$db->Quote($search).($extended?" IN BOOLEAN MODE":"").")")." as relev FROM ".$rh->db_prefix.
          "records as r WHERE (".($title?"":"match(body) against (".$db->Quote($search).($extended?" IN BOOLEAN MODE":"").") or").
          " lower(tag) like lower(".$db->Quote("%".$search."%").") or lower(subject) like lower(".
          $db->Quote("%".$search."%")."))".$where." ORDER BY ".$order;
//   $debug->Trace($sql);
   $rs = $db->Execute( $sql );
//   $debug->Error($this->security_handlers[$rs->fields["type"]]);

   // 2. filter them out
   $found = 0; $data = array(); $hash = array();
   $letters = array();
   while (!$rs->EOF)
   {
//   $debug->Trace ($rs->fields["supertag"]."=".$this->npj_object_address);
     if ($rs->fields["supertag"]!=$this->npj_object_address)
     {
      $cache->Store( "record", $rs->fields["record_id"], 1, $rs->fields ); 
      if ($principal->IsGrantedTo(  $this->security_handlers[$rs->fields["type"]], 
                                    "record", $rs->fields["record_id"]))
      {  $found++;
//         $debug->Trace_R( $rs->fields );
         $rs->fields["Link:tag"]    = $this->Href( $this->GetFullTag( $rs->fields["tag"], $rs->fields["supertag"] ), NPJ_RELATIVE  );
         if ($params["subject"]) $rs->fields["title"] = $rs->fields["subject"];
         else $rs->fields["title"] = $rs->fields["tag"];
         if ($rs->fields["title"] == "") $rs->fields["title"] = $rs->fields["supertag"];
         if ($where == "")
          $rs->fields["by"] = "<span class=\"by_\">. . . . . . . . . . . . . . . . . . . . . . . . (".
            $this->Link($rs->fields["edited_user_login"]."@".$rs->fields["edited_user_node_id"]).")</span>";
         else
          $rs->fields["by"] = "";
         $data[] = $rs->fields;
      }
     }
     $rs->MoveNext();
   }

//   $debug->Error("dssdfsd");
   // 3. choose template
   foreach( $templates as $k=>$v )
    if (($params["style"] == $k) || ($params["style"] == $v))
     $tplt = "List_".$v; 
 }

  // 4. parse 
 $tpl->LoadDomain( array(
    "checked2" => (($params["where"] == "node")?"checked":""),
    "checked" => ($title?"checked":""),
    "phrase" => $phrase,
    "Form:Search"    => $state->FormStart( MSS_GET, $this->_NpjAddressToUrl( $object->npj_object_address )."/search" , "name=\"search_form\""),
    "/Form"          => $state->FormEnd(),
 ));

  $tpl->Assign("Childs", "");
  $list = &new ListObject( &$rh, &$data );

  
  if ($search)
  {
    $result = $list->Parse("actions/search.html:".$tplt);

    $w = $rh->action_wrappers;
    // ??? ����� �������� Action:TITLE
    if (!$tpl->GetValue("Action:NoWrap") && ($form || ($params["wrapper"] != "none"))) 
    {
      $tpl->Assign("Action:CONTENT", $result);
      if (!isset($w[$params["wrapper"]])) $params["wrapper"] = "default";
      $result = $tpl->Parse( "actions/wrappers.html:wrapper_".$w[$params["wrapper"]] );
    }
    $tpl->Assign("Action:TITLE", $tpl->message_set["Actions"]["search"]);
  }
  // ��� �� ����� �������!
  $tpl->Assign("Action:NoWrap", 1);

  if ($params["style"] == "context") $form_add = "_context";
  if ($params["style"] == "context") if ($form) $search=0;
    
  return ($form?$tpl->Parse( "actions/search.html:Form".$form_add):"").($search?$result:"");

?>