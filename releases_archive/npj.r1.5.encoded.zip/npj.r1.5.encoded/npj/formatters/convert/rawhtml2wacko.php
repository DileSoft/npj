<?php


  include($rh->formatters_dir."html2text.php");


?>