<?php


  $text = $tpl->Format( $text, "wiki" );
//  include($rh->formatters_dir."absurl.php");


?>