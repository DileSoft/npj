<?php

  echo "/".$rh->base_url.$rh->object->_NpjAddressToUrl( $tpl->GetValue($what), 1 );

?>



