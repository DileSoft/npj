<?php

// $this->Load(3);

// $rh->Redirect( $this->Href( $principal->data["login"]."@".$principal->data["node_id"].":profile", 
//                NPJ_ABSOLUTE, IGNORE_STATE ), IGNORE_STATE);

include ( dirname(__FILE__)."/profile.php" );

?>