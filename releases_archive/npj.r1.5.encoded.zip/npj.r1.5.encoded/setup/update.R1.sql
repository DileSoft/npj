
ALTER TABLE %%NODE_PREF%%records_ref ADD user_datetime DATETIME NOT NULL AFTER server_datetime;
# %%@%%

CREATE TABLE %%NODE_PREF%%ban_ip (
id INT NOT NULL AUTO_INCREMENT,
ip VARCHAR( 16 ) NOT NULL ,
iplong INT NOT NULL ,
banned_datetime DATETIME NOT NULL ,
PRIMARY KEY ( id ) ,
INDEX ( iplong )
);
# %%@%%

ALTER TABLE %%NODE_PREF%%profiles ADD file_url_prefix VARCHAR(250) NOT NULL AFTER website_name;
# %%@%%

ALTER TABLE %%NODE_PREF%%users ADD account_class VARCHAR(250) NOT NULL AFTER account_type;
# %%@%%
ALTER TABLE %%NODE_PREF%%users ADD INDEX (account_class); 
# %%@%%

ALTER TABLE %%NODE_PREF%%users ADD domain_type INT DEFAULT '5' NOT NULL AFTER populate_type ;
# %%@%%

ALTER TABLE %%NODE_PREF%%records ADD commented_datetime DATETIME NOT NULL AFTER edited_datetime ,
ADD last_comment_id INT NOT NULL AFTER commented_datetime ;
# %%@%%


ALTER TABLE %%NODE_PREF%%records_ref ADD commented_datetime DATETIME NOT NULL AFTER user_datetime ,
ADD last_comment_id INT NOT NULL AFTER user_datetime ;
# %%@%%

ALTER TABLE %%NODE_PREF%%nodes ADD npj_version VARCHAR( 20 ) NOT NULL AFTER created_datetime ;
# %%@%%

UPDATE %%NODE_PREF%%nodes SET npj_version='R1.5' where is_local='1';
# %%@%%

ALTER TABLE %%NODE_PREF%%users ADD INDEX (alive); 
# %%@%%
