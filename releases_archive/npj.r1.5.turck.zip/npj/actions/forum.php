<?php
/*

  {{Forum  for=kuso@npj:WackoWiki
           [order ="server|user|commented"]
           [style ="tplt"]
           [mode  ="feed|list|forum"]

           
        }}


*/
//  $debug->Trace_R( $params );
//  $debug->Trace_R( $object->data );
//  $debug->Error( $object->class );
  $rh->UseClass( "ListObject", $rh->core_dir );
  $rh->UseClass( "Arrows", $rh->core_dir );


  // 1. default params
  $orders = array( "server"    => "r.server_datetime", 
                   "user"      => "r.user_datetime", 
                   "commented" => "(r.commented_datetime+ r.server_datetime - r.server_datetime*SIGN(last_comment_id))" );
  if (isset($orders[$params["order"]])) $order = $orders[$params["order"]];
  else                                  $order = $orders[   "commented"  ];

  $page_size       = 20;    // �� �������� �� ��������
  $page_frame_size = false; // ��� �������

  // 1.0. get keyword data
  $keyword = false;
  if ($params["for"])
  {
    $supertag = $this->_UnwrapNpjAddress( $params["for"] );
    $supertag = $this->RipMethods( $supertag, RIP_STRONG );     // ������ �� ��������� ������
    $keyword = &new NpjObject( &$rh, $supertag );
    $data   = $keyword->Load(2);
    if (!is_array($data)) $keyword = false;
  }
  if ($keyword === false) $keyword = &$object;
  $keyword->Load(2);

  // -. Need Moderation
  $need_moderation = 0;
  if ($params["type"] == "mod") 
  {
    if ($principal->IsGrantedTo("rank_greater", "account", $roubric->data["user_id"], GROUPS_MODERATORS))
     $need_moderation = 1;
  }

  // 2. construct SQL parts
  $where = 
         " keyword_id=".$db->Quote( $keyword->data["record_id"] )." and ".
         " syndicate >= 0 and ".
         " group1=0 and group2=0 and group3=0 and group4=0 and ". // public
         " need_moderation = ".$db->Quote($need_moderation);
  $table = "records_ref as r";

  // 3. init Arrows
  $arrows = &new Arrows( &$state, $where, $table, $page_size, $page_frame_size );
  $arrows->Parse( "actions/_arrows.html", "FORUM-ARROWS"  );

  // 4. go SQL
  $sql = "select distinct record_id".
         " from ".$rh->db_prefix.$table." where ".$where." order by ". $order." desc";

  $debug->Trace( $sql );

  $rs = $db->SelectLimit( $sql, $arrows->GetSqlLimit(), $arrows->GetSqlOffset() );
  $a = $rs->GetArray();
  $record_ids_q = array();
  foreach( $a as $k=>$v ) $record_ids_q[] = $db->Quote( $v["record_id"] );


  if (sizeof($record_ids_q) > 0)
  {

    // 5. get bodies & stuff
    include( dirname(__FILE__)."/__db_record.php" );
    $sql = "select".$__db_record_fields." from ".$__db_record_tables.
           " where r.record_id in (".implode(",",$record_ids_q).") ".
           " order by ".str_replace("server_datetime", "created_datetime",$order)." desc";
    $debug->Trace( "BODIES <br />".$sql );
    $rs = $db->Execute( $sql );  
    $data = $rs->GetArray();

//    $debug->Error_R( $data );
    // 5. preparse / rss
    foreach ($data as $k=>$item)
    {
      $cache->Store( "npj", $item["supertag"], 2, &$data[$k] ); 
      $data[$k] = $object->_PreparseArray( &$data[$k] );
      $data[$k]["even"] = $k%2;
      $data[$k]["non_empty_abstract"] = $this->rh->tpl->Format($item["body_post"], "non_empty_abstract");

      if ($rh->rss) $rh->rss->AddEntry( &$data[$k], RSS_FORUM );
    }
  } else $data = array();

  // 6. output
  if (sizeof($data) == 0)
  {
    // �������, ����� ����� ���������, ��� �� ������ ��������, ����� �����
    // !!! -> messageset
    return "";
  }
  else
  return $object->_ActionOutput( &$data, &$params, "forum" );


?>