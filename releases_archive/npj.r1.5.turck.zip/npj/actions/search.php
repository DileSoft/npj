<?php
/*
   {{search 
      [for="WackoWiki"] 
      [topic|title="1"] 
      [form="0|1|YES|no|none"] 
      [order="RELEVANCE|tag|subject|time"] 
      [where="JOURNAL|node"]
      [filter="posts|documents|ALL"]
      [limit/max="20"]
      [subject="tag|1|short"] 
      [mode, style] 
      [show_future, show_past, show_timeline]
   }}

*/
//
//  $debug->Trace_R( $params );
//  $debug->Error( $script_name );

  $rh->UseClass( "ListObject", $rh->core_dir );

  // part 0. default parameters
  if ($_REQUEST["_where"]) $params["where"]="node";

  // "limit", "max"
  if (!isset($params["max"])) 
   if (!isset($params["limit"]))
    $params["max"] = $params["limit"];

  // "subject"
  if (!isset($params["subject"])) $params["subject"] = 1;
  if ($params["subject"] == "tag") $params["subject"] = 0;
  if ($params["subject"] == "short") $params["subject"] = 1;

  // "show_*"
  $tpl->Assign( "show_past",     $params["show_past"]     );
  $tpl->Assign( "show_future",   $params["show_future"]   );
  $tpl->Assign( "show_timeline",        $params["show_future"] || $params["show_past"] );
  $tpl->Assign( "show_past_and_future", $params["show_future"] && $params["show_past"] );

  // "order"
  if ($params["order"] == "tag") $order = "tag ASC"; else
  if ($params["order"] == "subject") { $params["subject"]=1; $order = "subject ASC"; } else
  if ($params["order"] == "time") $order = "created_datetime DESC"; else
  $order = "relev DESC";

  // "topic", "title"
  if ($params["topic"] == "1" || $params["title"] == "1") $title=1;
  if ($_REQUEST["_topic"] == "on") $title=1;

  // "filter"
  if (!isset($params["filter"])) $params["filter"] = "all";

  // "form"
  $form = 1;
  if (isset($params["form"]) &&
      ($params["form"] == "0") 
       || (strtolower($params["form"]) == "none")
       || (strtolower($params["form"]) == "no")) $form = 0;

  // "for"
  if ($params["action_as_handler"] && !isset($params["for"])) $params["for"] = $params[0];
  if ($_REQUEST["_phrase"]) $params["for"]=$_REQUEST["_phrase"];

  // do search
  if (isset($params["for"])) 
  {
    $do_search = 1;
    $phrase = $params["for"];
    $debug->Trace("<h1>PHRASE</h1>".$phrase);

    if ($params["where"] == "node") $where = ""; else
    {
      $data = &$this->Load(2);
      $where = " AND r.user_id=".$db->Quote($data["user_id"]);
    }

    if ($params["filter"] == "posts")     $where.=" AND r.type=".$db->Quote(RECORD_POST);
    if ($params["filter"] == "documents") $where.=" AND r.type=".$db->Quote(RECORD_DOCUMENT);
    if ($params["filter"] == "announces") $where.=" AND r.is_announce>0 AND r.type=".$db->Quote(RECORD_POST);

    // alpha. check if we can use "IN BOOLEAN MODE"
    $rs = $db->Execute("SELECT VERSION() as v");
    if ($rs->fields["v"]{0}=="4") $extended = true;
    else $extended = false;

   // 1. compose & run sql
   $sql = "SELECT ".
           " 0 as is_empty, "." 0 as is_empty1, ".
           " r.record_id, r.record_id as id, subject, subject_post, tag, supertag, ".
           " tag as tag1, ".
           " user_id, edited_user_name, edited_user_login, edited_user_node_id, ".
           " created_datetime, edited_datetime, user_datetime, ".
           " body_post, crossposted, keywords, ".
           " number_comments, disallow_comments, ".
           " group1, group2, group3, group4, ".
           " type, is_digest, formatting, ".
           " rr.announced_id, rr.announced_comments, rr.announced_disallow_comments, rr.announced_supertag, rr.announced_title,".
           " is_announce, ".
           " version_tag, is_parent, depth, disallow_replicate, ".
           " pic_id, ".
           " rr.replicator_user_id, ".
          
          ($title?"1":"match(body) against (".$db->Quote($phrase).($extended?" IN BOOLEAN MODE":"").")")." as relev ".
          " FROM ".
           $rh->db_prefix."records as r left join ".
           $rh->db_prefix."records_rare as rr on rr.record_id=r.record_id ".
          " WHERE (".
          ($title?"":"match(body) against (".$db->Quote($phrase).($extended?" IN BOOLEAN MODE":"").") or").
          " lower(tag) like lower(".
           $db->Quote("%".$phrase."%").") or lower(subject) like lower(".
           $db->Quote("%".$phrase."%")."))".
           $where.
          " ORDER BY ".$order;
  
   $debug->Trace($sql);
   if (isset($params["max"]))
     $rs = $db->SelectLimit( $sql, $params["max"]*1 );
   else
     $rs = $db->Execute( $sql );

  // 2. filter them
  $found = 0; $data = array();
  while (!$rs->EOF)
  {
    $fields = $rs->fields;
    $debug->Trace("found ". $fields["supertag"] );
    $cache->Store( "record", $fields["record_id"], 1, $fields ); 
    if ($principal->IsGrantedTo(  $this->security_handlers[$fields["type"]], 
                                  "record", $fields["record_id"]))
    {  $found++;
       if ($fields["tag"] == "") 
       {
         $fields["tag"] = $tpl->message_set["JournalHomePage"];
         $fields["_empty_tag"] = 1;
         if ($supertag_issue == "") $fields["tag"].= " ". rtrim($fields["supertag"],":");
       } 
       if ($supertag[0] == "@") 
       {
         $fields["tag"] = $fields["login"]."@".$fields["node_id"].":".$fields["tag"];
         $fields["_empty_tag"] = 1;
       }

       $fields["datetime"] = $fields["created_datetime"]; // ���� ������� ���� -- ������� created
       $data[] = $fields;
       if (isset($params["max"]))
        if ($found >= $params["max"]) break;
    }
    $rs->MoveNext();
  }

  // ----- ���������� ������ ������ -----------------------

  // ��������� ����� � � RSS ����� (������ 2,3) -----------
  foreach ($data as $k=>$item)
  {
    $data[$k] = $object->_PreparseArray( &$data[$k] );
    if ($rh->rss) $rh->rss->AddEntry( &$data[$k], RSS_SEARCH );
  }

  // ����� ��������� ������ (������ 4) ----
  if (sizeof($data) == 0) 
  {
    // �������, ����� ����� ���������, ��� �� ������ ��������, ����� �����
    // !!! -> messageset
    $result = "������ �� �������";
  }
  else
  $result = $object->_ActionOutput( &$data, &$params, "list" );

  //$debug->Trace_R( $data );
  //$debug->Error( $result );
 }

 // 4. parse FORM (����������� ������ 4)
 $tpl->LoadDomain( array(
    "checked2" => (($params["where"] == "node")?"checked":""),
    "checked" => ($title?"checked":""),
    "phrase" => $phrase,
    "Form:Search"    => $state->FormStart( MSS_GET, $this->_NpjAddressToUrl( $object->npj_object_address )."/".$script_name , "name=\"search_form\""),
    "/Form"          => $state->FormEnd(),
 ));

  
  if ($params["style"] == "context") $form_add = "_context";
  if ($params["style"] == "context") if ($form) $do_search=0;
  
    
  return ($form?$tpl->Parse( "actions/search.html:Form".$form_add):"").
         ($do_search?$result:"");

?>