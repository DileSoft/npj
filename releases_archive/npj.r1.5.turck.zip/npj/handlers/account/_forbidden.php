<?php

  $tpl->Parse( "forbidden.common.html", "Preparsed:CONTENT" );
  return GRANTED; 

?>