<?php

  $rh->Redirect( $this->Href( $this->npj_object_address.":manage/freeze", NPJ_ABSOLUTE, IGNORE_STATE ), IGNORE_STATE );

?>