<?php

  $rh->UseClass("ListSimple", $rh->core_dir);
  $rh->UseClass("Form"      , $rh->core_dir);
  $rh->UseClass("Field"     , $rh->core_dir);
  $rh->UseClass("FieldString" , $rh->core_dir);
  $rh->UseClass("FieldRadio"  , $rh->core_dir);
  $rh->UseClass("ButtonList"  , $rh->core_dir);
  $rh->UseClass("FieldMultiple" , $rh->core_dir);
  $rh->UseClass("FieldMultiplePlus" , $rh->core_dir);

  ///////////////////////////

  {
     $rs = $db->Execute( "select group_id from ".$rh->db_prefix."groups where is_system=1 and group_rank=".GROUPS_SELF." and user_id=".
                         $db->Quote( $rh->account->data["user_id"] ) );
     $rh->account->group_nobody = 1*$rs->fields["group_id"];
     $rs = $db->Execute( "select group_id from ".$rh->db_prefix."groups where is_system=1 and group_rank=".GROUPS_FRIENDS." and user_id=".
                         $db->Quote( $rh->account->data["user_id"] ) );
     $rh->account->group_friends = 1*$rs->fields["group_id"];
     $rs = $db->Execute( "select group_id from ".$rh->db_prefix."groups where is_system=1 and group_rank=".GROUPS_COMMUNITIES." and user_id=".
                         $db->Quote( $rh->account->data["user_id"] ) );
     $rh->account->group_communities = 1*$rs->fields["group_id"];

     // accessgroups
     if ($rh->global_accessgroup_class)
     {
       $sql = "select u.user_name, u.login, u.node_id, u.user_id from ".$rh->db_prefix."users as u, ".$rh->db_prefix."user_groups as ug".
              " where u.account_class = ".$db->Quote($rh->global_accessgroup_class).
              " and ug.group_id = ".$db->Quote($rh->account->group_communities). // ������ ��, � ������� ������� �����
              " and ug.user_id = u.user_id ".
              " order by u.login asc";
       $rs  = $db->Execute( $sql );
       $a   = $rs->GetArray();
       $global_accessgroups = array( 0 => "������ ������ ��� ���������, ��� ������������" ); // !!!! -> to msgset
       foreach($a as $k=>$v)
         $global_accessgroups[ $v["user_id"] ] = "������ ������ ������ &laquo;<b>".$v["user_name"]."</b>&raquo;"; // !!!! -> to msgset
       $global_accessgroups_default = 0;
     }
     // --

    $group3 = array();
    $rs = $db->Execute("SELECT group_id, group_name FROM ".$rh->db_prefix."groups WHERE user_id=".$db->Quote($rh->account->data["user_id"])
    ." and group_rank=".GROUPS_FRIENDS." and is_system=0;"); $a=$rs->GetArray();
    $data4form=array(); $seldata4form=array();
    if (sizeof($a)==0) ; // ???refactor -- ����� ���������� ��������� ��������� ������ ��������� 
    else foreach ($a as $item) $data4form[$item["group_id"]]=$item["group_name"];
    if (!$is_new) 
    if ($this->data["group1"] == 0) $seldata4form=-1;
    else
    if ($this->data["group1"] == $rh->account->group_nobody) $seldata4form=0;
    else
    if ($this->data["group1"] == $rh->account->group_friends) $seldata4form=-2;
    else
    if ($this->data["group1"] == $rh->account->group_communities) 
    {
      $seldata4form=-3;
      $global_accessgroups_default = $this->data["group3"]; // � ������� ������ ����� ������� ���������� ������ �������
    }
    else
    {
     if ($this->data["group1"]) $seldata4form[] = $this->data["group1"];
     if ($this->data["group2"]) $seldata4form[] = $this->data["group2"];
     if ($this->data["group3"]) $seldata4form[] = $this->data["group3"];
     if ($this->data["group4"]) $seldata4form[] = $this->data["group4"];
    }
    if (sizeof($seldata4form) == 0) $seldata4form = -1;
    $post_access_field_config = array(
                          "field" => "groups",
                          "maxsize" => 4,
                          "data_plain" => 1,
                          "default" => $seldata4form,
                          "data" => $data4form,

                          "radio_data"    => $global_accessgroups,
                          "radio_default" => $global_accessgroups_default,

                          "db_ignore" => 1,
                                     );
    if (sizeof($global_accessgroups) > 1)
      $group3[] = &new FieldMultiplePlus( &$rh, $post_access_field_config );
    else
      $group3[] = &new FieldMultiple( &$rh, $post_access_field_config );
  }

  ///////////////////////////
      $form_config = array(
      "db_table"    => $rh->db_prefix."records", 
      "db_id"       => "record_id",
      "message_set" => $rh->message_set."_form_RecordGroups",
        );
      $form_buttons = array(
          array( "name" => $tpl->message_set["ButtonTextUpdate"],  
                 "tpl_name" => "forms/buttons.html:Update", "handler" => "_nothing", "default"=>1 )
          );
      $form_buttons[] = 
          array( "name" => $tpl->message_set["ButtonTextCancel"],  
                 "tpl_name" => "forms/buttons.html:Cancel", "handler" => "_cancel", "default"=>1 );

      $form_fields = array(  &$group3, );

    $form = &new Form( &$rh, &$form_config, &$form_fields, &$form_buttons );

  ///////////////////////////




?>