<?php

  $this->message_set["form_nessesary" ] = "<span class=\"alert\">*</span>";

?>