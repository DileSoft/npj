<?php
//  {{ClusterFacet style,filter,order,subject }}

  array_unshift( $params, $this->npj_object_address );
  return include( $dir."/facet.php" );
?>
