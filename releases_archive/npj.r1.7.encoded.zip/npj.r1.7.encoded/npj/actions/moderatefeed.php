<?php
//  {{ModFeed }}

  return include( $dir."/modfeed.php" );
?>
