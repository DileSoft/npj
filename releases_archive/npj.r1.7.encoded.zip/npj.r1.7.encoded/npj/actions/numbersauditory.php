<?php

  
 $tpl->Assign("Action:NoWrap", 1);


  $sql = "SELECT count( * ) as totals ".
         "FROM ".$rh->db_prefix."users AS u, ".
                 $rh->db_prefix."profiles AS p ".
         "WHERE alive = 1 AND account_type = 0 AND u.user_id = p.user_id AND PERIOD_DIFF( last_login_datetime, NOW( ) ) < 1 AND PERIOD_DIFF( last_login_datetime, creation_date ) > 1 ";

  $rs = $db->Execute( $sql );

  return $rs->fields["totals"];

?>