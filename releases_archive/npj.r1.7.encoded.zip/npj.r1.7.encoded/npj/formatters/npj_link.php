<?php

  echo $rh->object->Link( $text );

?>