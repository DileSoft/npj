<?php

if ($text == "") return;

$rh->UseClass("typografica", $rh->formatters_classes_dir);

$typo = &new typografica( &$this->config );
print $typo->correct($text, false);


?>