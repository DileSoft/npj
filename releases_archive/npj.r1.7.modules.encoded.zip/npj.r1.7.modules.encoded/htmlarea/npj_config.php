<?php

//  from ../config_modules.php
//  $this === $rh
  $this->use_htmlarea_as_richedit = true;

?>
