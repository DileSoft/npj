<?php
//  {{ClusterChanges [style="simple|brief|full"]}}

  array_unshift( $params, $this->npj_object_address );
  return include( $dir."/changes.php" );
?>