<?php
//  {{NodeRecentChanges [style="simple|brief|full"]}}

  array_unshift( $params, "@" );
  return include( $dir."/changes.php" );
?>
