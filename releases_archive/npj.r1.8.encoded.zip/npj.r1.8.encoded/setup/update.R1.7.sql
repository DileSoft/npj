UPDATE %%NODE_PREF%%nodes SET npj_version='R1.8' where is_local='1';
# %%@%%
