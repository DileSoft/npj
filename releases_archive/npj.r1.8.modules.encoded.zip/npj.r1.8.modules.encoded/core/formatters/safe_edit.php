<?php

  $text = $tpl->GetValue( $text );

  $text = htmlspecialchars( $text );

  echo $text;

?>