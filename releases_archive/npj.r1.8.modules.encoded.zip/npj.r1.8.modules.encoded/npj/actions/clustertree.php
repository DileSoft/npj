<?php
//  {{ClusterTree style=ol }}

  array_unshift( $params, $this->npj_object_address );

  return include( $dir."/tree.php" );
?>
