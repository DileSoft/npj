<?php


  $tpl->Assign( "Preparsed:READABLE", 0 );
  $tpl->Assign( "Action:NoWrap", 1);
  return "";

?>