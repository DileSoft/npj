<?php
//  {{JournalFeed style, depth }}

  $params["for"] = $this->npj_account.":";
  return include( $dir."/feed.php" );
?>
