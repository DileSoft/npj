<?php
echo "<!--no"."typo-->";
echo "<div class=\"code\">";
highlight_string($text);
echo "</div>";
echo "<!--/no"."typo-->";
?>