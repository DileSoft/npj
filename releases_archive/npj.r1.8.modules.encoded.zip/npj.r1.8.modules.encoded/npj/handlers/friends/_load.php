<?php

  return "empty";

?>