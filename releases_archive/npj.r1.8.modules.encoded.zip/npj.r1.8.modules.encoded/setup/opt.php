<?php
test($lang["TestZendOpt"], true, $lang["TestZendOptFailed"], 1);
?>