<?php

  return include( dirname(__FILE__)."/issue_view.php" );

?>