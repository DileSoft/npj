<?php


  $tpl->Assign( "Action:NoWrap", 1);
  $object->_category_mode = $params[0];
  return "";


?>