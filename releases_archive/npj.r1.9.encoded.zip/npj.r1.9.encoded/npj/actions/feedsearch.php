<?php
//  {{NodeSearch ...}}

  $params["mode"] = "feed";
  $params["filter"] = "posts";
  return include( $dir."/search.php" );
?>
