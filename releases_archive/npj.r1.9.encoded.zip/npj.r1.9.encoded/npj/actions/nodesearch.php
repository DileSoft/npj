<?php
//  {{NodeSearch ...}}

  $params["where"] = "node";
  return include( $dir."/search.php" );
?>
