<?php


echo "<tt style=\"cursor:help\" title=\"".$tpl->Format($text,"typografica")."\">(?)</tt>";

?>