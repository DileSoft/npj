<?php
print("<small>".htmlspecialchars($text)."</small>");
?>