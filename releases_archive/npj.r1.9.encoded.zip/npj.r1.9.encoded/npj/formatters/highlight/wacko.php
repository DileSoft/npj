<?php

  echo $tpl->Format($text, "wacko");

?>