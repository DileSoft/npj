<?php

  // ??? extremely dirty
  echo $tpl->Format( $text, "html2text" );

?>