<?php
  $this->message_set = array(
   );
?>