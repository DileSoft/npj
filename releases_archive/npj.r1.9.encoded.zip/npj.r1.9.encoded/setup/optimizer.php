<?php

ob_start();
phpinfo();
$info = ob_get_contents();
ob_end_clean();
preg_match("/(zend\s*optimizer)/i", $info, $matches);
//if (!$matches[1]) die("No optimizer");
test($lang["TestZendOpt"], $matches[1], $lang["TestZendOptFailed"], 1);
?>