<?php

  $text = $tpl->Format( $text, "convert/simplebr2rawhtml" );
  include($rh->formatters_dir."convert/rawhtml2wacko.php");

?>