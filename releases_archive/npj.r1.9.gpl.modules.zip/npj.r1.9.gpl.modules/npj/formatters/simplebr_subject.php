<?php

include($rh->formatters_dir."safehtml_simple.php");
//$text = $this->Format($text, "safehtml_simple");
//print($text);

?>