<?php
  //engine directories
  $this->engine_dir          = "../core/";
  $this->principal_dir       = "../core/";
  $this->core_dir            = "../core/classes/";
  $this->classes_dir         = "../core/classes/";
  $this->security_dir        = "../core/security/";
  $this->formatters_dir      = "../core/formatters/";
  $this->handlers_dir        = "../core/handlers/";
  $this->templates_dir       = "../core/templates/";
  $this->templates_magic_dir = "../core/tpl_magic/";
  $this->templates_cache_dir = "../_templates/";
  $this->libraries_dir       = "../lib/";
    $this->db_al_dir           = "ADODBLite";

  $this->user_pictures_dir = "../images/userpics/";
  $this->npj_classes_dir     = "../npj/classes/";
  $this->classes_dir         = "../npj/classes/";
  $this->principal_dir       = "../npj/";
  $this->security_dir        = "../npj/security/";
  $this->formatters_dir      = "../npj/formatters/";
  $this->formatters_classes_dir = "../npj/formatters/classes/";
  $this->handlers_dir        = "../npj/handlers/";
  $this->templates_cache_dir = "../_templates/";
  $this->messagesets_dir     = "../npj/messagesets/";
  $this->npj_actions_dir     = "../npj/actions/";
  $this->themes_dir          = "../npj/themes/";
     $this->templates_dir       = "templates/";
     $this->templates_magic_dir = "tpl_magic/";
     $this->themes_www_dir      = "npj/themes/";
  

  $this->custom_handlers_dir     = "../npj/handlers/";
  $this->custom_actions_dir      = "../npj/actions/";

?>