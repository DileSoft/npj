<?php

  $text = $tpl->Format( $text, "convert/wacko2simplebr" );
  include($rh->formatters_dir."convert/rawhtml2simplebr.php");

?>