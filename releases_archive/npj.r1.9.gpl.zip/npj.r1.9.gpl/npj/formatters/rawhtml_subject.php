<?php

//$text = $this->Format($text, "safehtml_simple");
//print($text);
include($rh->formatters_dir."safehtml_simple.php");

?>