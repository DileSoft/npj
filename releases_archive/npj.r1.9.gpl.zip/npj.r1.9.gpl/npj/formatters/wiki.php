<?php

$text = $this->Format($text, "wacko");
//$text = $this->Format($text, "post_wacko");
//print($text);
include($rh->formatters_dir."post_wacko.php");


?>
