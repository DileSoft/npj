This is slightly modified version of Text_Highlighter 0.5.1.

See http://pear.php.net/package/Text_Highlighter