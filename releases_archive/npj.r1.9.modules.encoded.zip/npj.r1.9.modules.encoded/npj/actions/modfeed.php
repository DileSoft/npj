<?php
//  {{ModFeed }}

  $params["type"] = "mod";
  $params["mode"] = "list";
  $params["style"] = "ul";
  return include( $dir."/feed.php" );
?>
