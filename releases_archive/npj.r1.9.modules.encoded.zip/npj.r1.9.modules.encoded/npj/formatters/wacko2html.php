<?php

  // ??? extremely dirty

  echo $tpl->Format( $text, "wiki" );
?>