<?php

  $this->method = "show";
  $this->Handler( $this->method, $params, $principal );

?>