<?php
  // top level configuration 
  include("core/config.php");
  include("npj/config.php");
  if (!file_exists("config_tunes.php")) die ("Please, run installer!");
  include("config_tunes.php");
  include("config_db.php");
?>