<?php


$text = $what;

print($text);


?>