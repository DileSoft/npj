<?php
//  {{CommonUsageStats}}

  $params["public"] = 1;
  return include( $dir."/usagestats.php" );
?>
