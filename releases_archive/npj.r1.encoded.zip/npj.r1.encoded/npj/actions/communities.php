<?php
//  {{Communities}}

  $params["show"] = "communities";
  return include( $dir."/directory.php" );
?>
