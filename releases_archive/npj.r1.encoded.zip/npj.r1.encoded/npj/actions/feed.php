<?php

// {{feed [type="mod|my|corr|correspondents|rank"] [minrank="5"] [groups="25,167"] 
//        [mode=, style= -- �� ����� ������������] 
//        [pagesize="20"]                 -- ������ �� ��������, ��� �� ����!
//        [for="kuso@npj:�����������"]
//        [filter="announce|events|documents"] or [param0="announce"]
//        [dtfrom="2003-09-15"]           
//        [dtto  ="2003-09-23"]           
//        [dt    ="today|yesterday"  param0="today/yesterday"]
// }}
//  searches for $_REQUEST["before"], $_REQUEST["after"]

//  $debug->Trace_R( $params );
//  $debug->Trace_R( $object->data );
//  $debug->Error( $object->class );
  $rh->UseClass( "ListObject", $rh->core_dir );

  // ��� �� ����� �������!
  $tpl->Assign("Action:NoWrap", 1);

  // ��� ���������
  $is_digest = (strtolower($params["mode"]) == "digest");

  // ���� ������ ������ ���
  $filter_announce="";
  if ($params[0] == "announce") 
  { array_shift( $params ); 
    $filter_announce=">0"; 
    if ($params[0] == "events")    { $filter_announce="=1"; array_shift( $params ); }
    if ($params[0] == "documents") { $filter_announce="=2"; array_shift( $params ); }
  }
  // ���������� ������� �� �������������� ������
  if ($params["filter"] == "announce")  $filter_announce=">0"; 
  if ($params["filter"] == "events")    $filter_announce="=1"; 
  if ($params["filter"] == "documents") $filter_announce="=2"; 
  if ($filter_announce) $filter_announce = " and m.announce".$filter_announce." ";

  // ���� �� �������/������
  if ($params[0] == "today")     { $params["dt"] = "today";     array_shift( $params ); }
  if ($params[0] == "yesterday") { $params["dt"] = "yesterday"; array_shift( $params ); }


  // �������� ��� ����� -- ��� ��� �����������������
  if ($params["type"] == "corr" || $params["type"] == "correspondents" ) $type = "corr"; else
  if ($params["type"] == "rank" ) $type = "rank"; else
  $type = "my"; 

  // ����� ��� �������
  if ($params["for"])
  {
    $supertag = $this->_UnwrapNpjAddress( $params["for"] );
    $supertag = $this->RipMethods( $supertag, RIP_STRONG );     // ������ �� ��������� ������

    $roubric  = &new NpjObject( &$rh, $supertag );
    $roubric_data = &$roubric->Load(1);
    if (!is_array($roubric_data))
    {
      $roubric = &$object;
      unset($params["for"]);
    } else $type = "for";
  } else 
  {
    if (($type == "my") && ($object->data["tag"] != "")) $type="for";
    $roubric = &$object;
  }


  // ���������� ������ ��������
  if (!isset($params["pagesize"])) 
   $params["pagesize"] = $rh->account->data["_".($type=="my"?"personal":"friends")."_page_size"];
  if (!isset($params["pagesize"])) 
   $params["pagesize"] = 20;

  // -. Need Moderation
  $need_moderation = 0;
  if ($params["type"] == "mod") 
  {
    if ($principal->IsGrantedTo("rank_greater", "account", $roubric->data["user_id"], GROUPS_MODERATORS))
     $need_moderation = 1;
  }

  // 0. frequent numbers
  $owner_id = $rh->account->data["user_id"];
  $user_id  = $principal->data["user_id"];
  $data = array(); // here will be records

  $friends = array();
  $psize    = $params["pagesize"];
//  $psize    = 5;
  $before = $_REQUEST["before"];
  $after = $_REQUEST["after"];
  $state->Free( "before" ); // ??? place smw else
  $state->Free( "after" ); // ??? place smw else
  $mode = "Before"; $rmode = "After";
  $rvalue = $before;  
  if ($before)
  { 
    $lasttime = $db->Quote(date("Y-m-d H:i:s", 
  //          HH                   mm                    ss                    MM                   dd                   YYYY
      mktime( substr($before,8,2), substr($before,10,2), substr($before,12,2), substr($before,4,2), substr($before,6,2), substr($before,0,4) )
              ));
  }
  else $lasttime = $db->Quote(date("Y-m-d H:i:s"));
  if ($after)
  { 
    // reverse mode
    $mode = "After"; $rmode = "Before";
    $rvalue = $after;
    $rlasttime = $db->Quote(date("Y-m-d H:i:s", 
  //          HH                   mm                    ss                    MM                   dd                   YYYY
      mktime( substr($after,8,2), substr($after,10,2), substr($after,12,2), substr($after,4,2), substr($after,6,2), substr($after,0,4) )
              ));
  }
  // ������������ ����� �� ������
  $filter_dt = " AND m.server_datetime < ".$lasttime;
  if ($rlasttime) $filter_dt = " AND m.server_datetime > ".$rlasttime;
  if ($params["dt"] == "today")
  { 
    $params["dtfrom"] = date( "Y-m-d 00:00:00" ); 
    $params["dtto"]   = date( "Y-m-d 23:59:59" ); 
  }
  if ($params["dt"] == "yesterday")
  { 
    $yesterday = mktime (0,0,0,date("m")  ,date("d")-1,date("Y")); 
    $params["dtfrom"] = date( "Y-m-d 00:00:00", $yesterday ); 
    $params["dtto"]   = date( "Y-m-d 23:59:59", $yesterday ); 
  }
  if ($params["dtto"])
    $filter_dt = " AND m.server_datetime <= ".$db->Quote($params["dtto"]);
  if ($params["dtfrom"])
    $filter_dt .= " AND m.server_datetime >= ".$db->Quote($params["dtfrom"]);

  $pagesize = $psize;
  
  if ($type == "my")
  {
     $mysql = "select r.record_id from ".$rh->db_prefix."records as r, ".$rh->db_prefix."users as u ".
                 " where r.supertag = CONCAT(u.login,".$db->Quote("@").
                 ($rh->account->data["node_id"]==$rh->node_name?
                      ",u.node_id,":
                      ",u.node_id,".$db->Quote("/".$rh->node_name).",")
                 .$db->Quote(":").
                 ") ".
                 "and u.user_id=".$db->Quote( $owner_id )." and r.user_id=u.user_id";
     $debug->Trace("<b>MY FEED:</b> ".$mysql);                          
     $rs = $db->Execute( $mysql );
     $friends[] = $rs->fields["record_id"];
  }
  else 
  if ($type == "for")
  {
    $friends[] = $roubric->data["record_id"];
  }
  else
  {
  
    // 1. �������� ������
    if ($params["groups"]) $_groups = explode( ",", $params["groups"] );  else $_groups = array();
    $gs = sizeof($_groups);
    $groups = array();
    $rs = $db->Execute("select group_id, group_rank, is_default, is_system from ".$rh->db_prefix.
                       "groups where is_system<2 and user_id=".$db->Quote($owner_id));
    $a = $rs->GetArray(); 
    // ���� ������ ��� ��������� ������� �������
    foreach ($a as $item) 
    if (($gs==0) && $item["is_default"])            $groups[]=$item["group_id"];
    else if (in_array($item["group_id"], $_groups)) $groups[]=$item["group_id"];

    // ���� �� ��� �����, �� ���� "���� �� ���������"
    $gs = sizeof($groups);
    if ($gs == 0)
    foreach ($a as $item)
    {
      if ($type=="corr")
      if (($item["group_rank"]==GROUPS_REPORTERS) && ($item["is_system"] == 1)) 
          { $groups[] = $item["group_id"]; break; }
      if ($type=="rank") 
      {
//r        $debug->Trace( $item["group_rank"]." ** ".$item["group_id"] );
        if (($item["group_rank"]>=$params["minrank"]) && ($item["is_system"] == 1)) 
            { $groups[] = $item["group_id"]; }
      }
    }

    // 2. �������� ���������� �����
    if (sizeof($groups) == 0) $no=1;
    if (!$no)
    {
      $rs = $db->Execute("select distinct root_record_id from ".$rh->db_prefix."user_groups as ug, ".$rh->db_prefix."users as u ".
                         "where ug.user_id=u.user_id and ug.group_id in (".implode(", ",$groups).")");
      $a = $rs->GetArray(); 
      foreach( $a as $item ) $friends[] = $item["root_record_id"];
    }
    if (sizeof($friends) == 0) $no=1;
  }

//r $debug->Trace_R( $groups );
//r $debug->Trace_R( $friends );
// $debug->Error("$owner_id::: minrank = ".$params["minrank"]);
 if (!$no)
 {
  // pre3. ����� ������������� �������� ����������, � ������� ������� ���������
  $m1 = $debug->_getmicrotime(); // ???(DBG)
  $rs = $db->Execute( "select distinct g.user_id from ".$rh->db_prefix."user_groups as ug, ".
                      $rh->db_prefix."groups as g where g.group_id = ug.group_id and ".
                      " g.group_type > 2 and g.group_rank >=".GROUPS_LIGHTMEMBERS.
                      " and ug.user_id = ". $db->Quote($principal->data["user_id"]) );
  $a = $rs->GetArray(); $g = array();
  foreach( $a as $v ) $g[] = $v["user_id"];

  $debug->Trace("principal is somewhat member in accounts: ". implode(", ", $g));

  if (sizeof($g) > 0)
   $sql_add = "OR (g.user_id <> ug.user_id AND ug.user_id = m.keyword_user_id and ug.user_id IN (". implode(", ",$g) .") )";
  else
   $sql_add = "";


  $m2 = $debug->_getmicrotime(); // ???(DBG)

  // 3. �����������, 3.4� ������
//       m.announce, 
//       m.keyword_id, m.keyword_user_id,
  $sql = "
SELECT 
       m.record_id, m.owner_id, 
       m.group1, m.group2 
FROM 
  ".$rh->db_prefix."records_ref as m,
  ".$rh->db_prefix."groups as g,
  ".$rh->db_prefix."user_groups as ug
WHERE                       
 ( 
   m.keyword_id in (".implode(",",$friends).")
 )
AND
 ( 
   (m.group1 = 0 AND g.group_rank=".GROUPS_SELF.") OR
   (g.group_rank=".GROUPS_SELF." and ug.user_id = ".$user_id.") OR
   ( 
     ((m.group1 = g.group_id OR m.group2 = g.group_id OR
       m.group3 = g.group_id OR m.group4 = g.group_id)
     ) 
       AND g.group_rank < ".GROUPS_SELF."
       AND
       (
         ug.user_id = ".$user_id."
         ".$sql_add."
       )
   ) 
 )
".
($type!="my"?"AND m.syndicate = 1":"AND m.syndicate > -1").
" 
AND m.need_moderation = ".$need_moderation."

AND g.user_id = m.owner_id
AND g.group_id = ug.group_id
".
$filter_dt.
$filter_announce."

ORDER BY m.server_datetime ".($rlasttime?"ASC":"DESC").", record_id DESC";
  // patches: kuso changed "m.priority=0" from "m.priority>0" due to refactoring of priority AND THEN REMOVED priority at all
  //          kuso added   "m.syndicate=1" due to refactoring of priority
  //          kuso added   "m.need_moderation=xxx" for moderation support
  //          kuso added   "select ... m.keyword*" to support xposted
  //          kuso added   "m.group1, m.group2" to support friends/private notification
  //          kuso added   << (m.group2=-1 AND m.keyword_user_id=".$user_id." AND g.group_id=gc.group_id 
  //                          AND g.group_rank=".GROUPS_SELF.") OR >> to fix "no-private" bug
  //          kukutz added  ASC/DESC flipper
  //          kuso splitted out "pre3" section and removed ug + ugc
  // 14022004
  //          kuso removed that line:
  //              (m.group2='-1' AND m.keyword_user_id=".$user_id." AND g.group_rank=".GROUPS_SELF.") OR
  //          kuso replaced it by line:
  //              (g.group_rank=".GROUPS_SELF.") OR
  //          kuso removed all ref-based data from SELECT <..field list..>
  //          kuso+kukutz tested over SELECT DISTINCT and claim that inefficient, then simple doubled pagesize for record_id`s gathering =)
  //          kuso added << $type="my" >> part


  // bonus:     ($nodeuser = ug.user_id AND ".$user_id."=gc.user_id AND gc.group_rank=".GROUPS_SELF.") OR 
  // anus seems to be fixed:  disallow_syndicate missing.

  // anus: ????   why there is priority=0, =1 in some cases. what does it meanz?

  $debug->Trace( "<b>FEED SUPER QUERY:</b>".$sql );
  $rs = $db->SelectLimit( $sql, floor($pagesize*2.5) );
  $record_ids = array(); $a = $rs->GetArray();

//r  $debug->Trace_R( $a );

  $_rids = array();
  foreach( $a as $k=>$item ) 
  {
    $_rids[ $item["record_id"] ] = 1;
  }
  $_ridsize=0;
  foreach( $_rids as $k=>$v ) 
  {
    $_ridsize++;
    $record_ids[] = $k;
  }

  // ������, ��������� �� �� ��� ������
  if ($_ridsize <= $pagesize) $reach_bottom = 1;
  else
  { 
    $reach_bottom=0;
    //array_pop($a); // ??? �������� ��� after ���� array_shift()
  }
  
  $m3 = $debug->_getmicrotime(); // ???(DBG)
  
  /*
        D E P R E C A T E D

  $by_id = array(); $all_pub = array(); $by_pub = array();
  // ���������, �������� CROSS POSTED
  foreach( $a as $k=>$item ) 
  {
    $by_id[ $item["record_id"] ] = &$a[$k];
    $record_ids[] = $item["record_id"];

    if ($item["owner_id"] != $item["keyword_user_id"])
    {
      $by_id[ $item["record_id"] ]["crossposted"] = array();
      $all_pub[] = $item["keyword_user_id"];
      if (!is_array($by_pub[$item["keyword_user_id"]])) $by_pub[$item["keyword_user_id"]] = array();
      $by_pub[ $item["keyword_user_id"] ][] = &$by_id[ $item["record_id"] ];
    }
  }

  if (sizeof($record_ids) == 0) $no = 1;
 }
 if (!$no)
 {
  // 3.2. �������� ��� �����������
  if (sizeof($all_pub) > 0)
  {
    $sql = "select user_id, user_name, login, node_id from ".$rh->db_prefix."users where user_id in (".implode(",",$all_pub).")";
    $rs = $db->Execute($sql);
    $a = $rs->GetArray();
    foreach( $a as $item )
     if (is_array($by_pub[ $item["user_id"] ]))
      foreach($by_pub[ $item["user_id"] ] as $v=>$rec)
      {
        $by_id[ $rec["record_id"] ]["crossposted"][] = $object->Link( $item["login"]."@".$item["node_id"] );
        $debug->Trace($rec["record_id"]." ������������ �: ".$item["login"]."@".$item["node_id"]);
      }
    {
    }
  }
           end of D E P R E C A T E D
  */
  // 3.5. �������� ������ �� �� ids.
  // ??? ���������, ������������� �� ������������ �� ����� ��� (2)
  if (sizeof($record_ids) == 0) $data = array();
  else
  {
    $sql = "select ".
           " r.record_id, subject, subject_post, tag, supertag, ".
           " user_id, edited_user_name, edited_user_login, edited_user_node_id, ".
           " created_datetime, edited_datetime, user_datetime, ".
           " body_post, crossposted, keywords, ".
           ($is_digest?"body, ":"").
           " number_comments, disallow_comments, ".
           " group1, group2, group3, group4, ".
           " type, is_digest, formatting, ".
           " rr.announced_id, rr.announced_comments, rr.announced_disallow_comments, rr.announced_supertag, rr.announced_title,".
           " is_announce, ".
           " version_tag, is_parent, depth, disallow_replicate, ".
           " pic_id, ".
           " rr.replicator_user_id ".
           "  from ".
           $rh->db_prefix."records as r left join ".
           $rh->db_prefix."records_rare as rr on rr.record_id=r.record_id where  r.record_id in (".implode(",",$record_ids).") ".
           " order by created_datetime DESC"; // [!!!] add user_datetime option
    $rs = $db->SelectLimit( $sql, $pagesize );  
    $data = $rs->GetArray();
  }

  $account_object = &new NpjObject( &$rh, $object->npj_account );
  $account_object->Load(2);
  $needmod = (($type == "for") || ($type == "my")) && ($account_object->data["account_type"] != ACCOUNT_USER)
             && $account_object->HasAccess( &$principal, "rank_greater", GROUPS_MODERATORS);
  foreach($data as $k=>$item)
  {
     if (!$needmod) $data[$k]["Href:mod"] = "";
     else $data[$k]["Href:mod"] = $object->Href( "/manage/moderate/".$data[$k]["record_id"], NPJ_RELATIVE, STATE_IGNORE );
     $data[$k]["is_owner"] = $data[$k]["user_id"] == $principal->data["user_id"];
     $data[$k]["announce"] = $by_id[ $item["record_id"] ]["announce"];   // ����� ��� ������
     $data[$k]["datetime"] = $data[$k]["user_datetime"];                 // ����� ���� ������� ��������

  }
 } 
 if (!isset($data)) $data = array();

  // ----- ���������� ������ ������ -----------------------

  $m4 = $debug->_getmicrotime(); // ???(DBG)
  $ms1 = $m2-$m1;
  $ms2 = $m3-$m2;
  $ms3 = $m4-$m3;
  $tpl->Assign("Milestone:Debug", $params["debug"]);
  $tpl->Assign("Milestone:Feed_Groups", sprintf("[%0.4f] ",$ms1));
  $tpl->Assign("Milestone:Feed_Super",  sprintf("[%0.4f] ",$ms2));
  $tpl->Assign("Milestone:Feed_Bodies", sprintf("[%0.4f] ",$ms3));

  if ($params["debug"] == 2) $debug->Error("Debug haltpoint");

  // ��������� ����� � � RSS ����� (������ 2,3) -----------
  foreach ($data as $k=>$item)
  {
    $cache->Store( "npj", $item["supertag"], 2, &$data[$k] ); 
    $data[$k] = $object->_PreparseArray( &$data[$k] );

    if ($rh->rss) $rh->rss->AddEntry( &$data[$k], RSS_FEED );
  }

  // ��� � ��������
  if ($is_digest) 
  {
    $tpl->Assign("Preparsed:DIGEST", &$data );
    return "";
  }

  // ����� ��������� ������ (������ 4) ----
  $params["subject"] = 1; // � ������ ��� �����, ������� �������� ���� ������ ��������, ����� �� ���������
  if ($mode=="Before")
  {
    if (!$reach_bottom) $params["show_past"] = 1;
    else                $params["show_past"] = 0;
    $params["show_future"] = ($before != "");
    $deeper = str_replace(" ","",str_replace("-","",str_replace(":","",
                                ($data[ sizeof($data)-1 ]["created_datetime"]))));
  }
  else
  {
    if (!$reach_bottom) $params["show_future"] = 1;
    else                $params["show_future"] = 0;
    $params["show_past"] = 1;
    $deeper = str_replace(" ","",str_replace("-","",str_replace(":","",
                                ($data[ 0 ]["created_datetime"]))));
  }
  $tpl->Assign( "show_past",     $params["show_past"]     );
  $tpl->Assign( "show_future",   $params["show_future"]   );
  $tpl->Assign( "show_timeline",        $params["show_future"] || $params["show_past"] );
  $tpl->Assign( "show_past_and_future", $params["show_future"] && $params["show_past"] );

  $tpl->Assign( $mode,  $deeper );
  $tpl->Assign( $rmode, $rvalue );
  if (sizeof($data) == 0)
  {
    // �������, ����� ����� ���������, ��� �� ������ ��������, ����� �����
    // !!! -> messageset
    return "";
  }
  else
  return $object->_ActionOutput( &$data, &$params, "feed" );

?>