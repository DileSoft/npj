<?php
//  {{Index for, depth=1, filter }}

  $params["index"] = 1;
  if (!$params["depth"]) $params["depth"] = 1;
  return include( $dir."/tree.php" );
?>
