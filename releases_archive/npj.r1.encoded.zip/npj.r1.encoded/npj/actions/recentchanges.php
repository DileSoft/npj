<?php
//  {{RecentChanges [style="simple|brief|full"]}}

  array_unshift( $params, $this->npj_account.":" );
  return include( $dir."/changes.php" );
?>
