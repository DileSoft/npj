<?php
//  {{Users}}

  $params["show"] = "users";
  return include( $dir."/directory.php" );
?>
