<?php
class WackoFormatter
{
  var $object;
  var $oldIndentLevel = 0;
  var $indentClosers = array();
  var $tdoldIndentLevel = 0;
  var $tdindentClosers = array();
  var $br = 1;
  var $intable = 0;
  var $intablebr = 0;
  var $cols = 0;

  function wackoFormatter( &$object )
  { 
    $this->object = &$object; 
    $this->LONGREGEXP = 
"/(".

// -- feed <CUT>
"\@\@(.*?)\@\@|".
"(<cut.*?<\/cut>)|".
"(<cut[^>]*>)|".

"\xa5\xa5.*?\xa5\xa5|".($object->GetConfigValue("allow_rawhtml")==1?"\<\#.*?\#\>|":"").
"\[\[(\S+?)([ \t]+([^\n]+?))?\]\]|\(\((\S+?)([ \t]+([^\n]+?))?\)\)|".
"\/\/([^\n]*?".
 "(".
 "\[\[(\S+?)([ \t]+([^\n]+?))?\]\]|\(\((\S+?)([ \t]+([^\n]+?))?\)\)".
 ")".
 "[^\n]*?)+\/\/|".
"\^\^\S*?\^\^|vv\S*?vv|".
">>.*?<<|".
"<\[.*?\]>|".
"\+\+[^\n]*?\+\+|".
"\b[[:alpha:]]+:\/\/\S+|mailto\:[[:alnum:]\-\_\.]+\@[[:alnum:]\-\_\.]+|\?\?\S\?\?|\?\?(\S.*?\S)\?\?|".
"\\\\\\\\[".ALPHANUM_P."\-\_\\\!\.]+|".
"\*\*[^\n]*?\*\*|\#\#[^\n]*?\#\#|\'\'.*?\'\'|\!\!\S\!\!|\!\!(\S.*?\S)\!\!|__[^\n]*?__|".
"\xA4\xA4\S\xA4\xA4|\xA3\xA3\S\xA3\xA3|\xA4\xA4(\S.*?\S)\xA4\xA4|\xA3\xA3(\S.*?\S)\xA3\xA3|".
"\#\|\||\#\||\|\|\#|\|\#|\|\|.*?\|\||".
"<|>|\/\/[^\n]*?\/\/|".
"\n[ \t]*=======.*?=======|\n[ \t]*======.*?======|\n[ \t]*=====.*?=====|\n[ \t]*====.*?====|\n[ \t]*===.*?===|\n[ \t]*==.*?==|".
"[-]{4,}|---\n?\s*|--\S--|--(\S.*?[^- \t\n\r])--|".
"\n(\t+|([ ]{2})+)(-|\*|[0-9,a-z,A-Z]{1,2}[\.\)](\#[0-9]{1,3})?)?|".
"\b[[:alnum:]]+[:]".ALPHANUM."[".ALPHANUM_P."\-\_\.\+\&\=]+|".
"~([^ \t\"\n]+)|".
($object->GetConfigValue("disable_tikilinks")==1?"":"\b(".UPPER.LOWER.ALPHANUM."*\.".ALPHA.ALPHANUM."+)\b|").
"(~?)(?<=[^\.".ALPHANUM_P."]|^)(((\.\.|!)?\/)?".UPPER.LOWER."+".UPPERNUM.ALPHANUM."*)\b|".
"(~?)".ALPHANUM_L."+\@".ALPHA_L."*(?!".ALPHANUM."*\.".ALPHANUM."+)(\:".ALPHANUM."*)?|".ALPHANUM_L."+\:\:".ALPHANUM."+|".
"\n)/sm";
    $this->page_id = $this->object->data["record_id"];
    if (!$this->page_id) $this->page_id = trim(substr(crc32(time()),0,5),"-");
  }

  function indentClose() 
  {
   if ($this->intable) $Closers = &$this->tdindentClosers;
   else $Closers = &$this->indentClosers;
   $c = count($Closers);
   for ($i = 0; $i < $c; $i++)
     $result .= array_pop($Closers);
   if ($this->intable) $this->tdoldIndentLevel = 0;
   else $this->oldIndentLevel = 0;
   return $result;
  }

  function wackoPreprocess($things)
  {
    $thing = $things[1];
    $wacko = &$this->object;
    $callback = array( &$this, "wackoPreprocess");
    // escaped text
    if (preg_match("/^\xa5\xa5(.*)\xa5\xa5$/s", $thing, $matches))
    {                                    
      return $matches[1];
    }
    // escaped text
    else if (preg_match("/^\"\"(.*)\"\"$/s", $thing, $matches))
    {                                    
      return "\xa5\xa5<!--notypo-->".str_replace("\n","<br />",htmlspecialchars($matches[1]))."<!--/notypo-->\xa5\xa5";
    }
    // code text
    else if (preg_match("/^\%\%(.*)\%\%$/s", $thing, $matches))
    {
      // check if a language has been specified
      $code = $matches[1];
      if (preg_match("/^\((.+?)\)(.*)$/s", $code, $matches))
      {
        list(, $language, $code) = $matches;
      }
      $formatter = strtolower($language);
      if ($formatter=="\xF1") $formatter="c";
      if ($formatter=="c") $formatter="comments";
      if ($formatter=="") $formatter="code";

      $output .= $wacko->Format(trim($code), "highlight/".$formatter);

      return "\xa5\xa5".$output."\xa5\xa5";
    }
    // actions
    else if (preg_match("/^\{\{(.*?)\}\}$/s", $thing, $matches))
    { // used in paragrafica, too
      return "\xa5\xa5<!--notypo-->\xA1\xA1".$matches[1]."\xA1\xA1<!--/notypo-->\xa5\xa5";
    }
    // if we reach this point, it must have been an accident.
    return $thing;
  }

  function wacko2callback($things)
  {
    $thing = $things[1];

    $wacko = &$this->object;
    $callback = array( &$this, "wacko2callback");
    
    // convert HTML thingies
    if ($thing == "<")
      return "&lt;";
    else if ($thing == ">")
      return "&gt;";
    // escaped text
    else if (preg_match("/^\xa5\xa5(.*)\xa5\xa5$/s", $thing, $matches))
    {                                    
      return $matches[1];
    }
    // convert @@....@@ to <CUT>....</CUT>
    else if (preg_match("/^@@(.*)@@$/s", $thing, $matches))
    {                                
      return "<cut>".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</cut>";
    }
    // convert simple skip <CUT....</CUT>
    else if (preg_match("/^(<cut(\s*)(\s".ALPHANUM."+=(([^>\"]+)|(\"[^\"]*\")))?>)(.*)(<\/cut>)$/si", $thing, $matches))
    {
     return $matches[1].preg_replace_callback($this->LONGREGEXP, $callback, $matches[7]).$matches[8];
    }
    // convert simple skip <CUT> without closer
    else if (preg_match("/^(<cut[^>]*>)$/si", $thing, $matches))
    {
     return $matches[1];
    }
    // escaped html
    else if (preg_match("/^\<\#(.*)\#\>$/s", $thing, $matches))
    {                                    
      return "<!--notypo-->".$wacko->Format($matches[1], "safehtml")."<!--/notypo-->";
    }
    // code text
    else if (preg_match("/^\%\%(.*)\%\%$/s", $thing, $matches))
    {
      // check if a language has been specified
      $code = $matches[1];
      if (preg_match("/^\((.+?)\)(.*)$/s", $code, $matches))
      {
        list(, $language, $code) = $matches;
      }
      $formatter = strtolower($language);
      if ($formatter=="\241") $formatter="c";
      if ($formatter=="c") $formatter="comments";
      if ($formatter=="") $formatter="code";

      $output .= $wacko->Format(trim($code), "highlight/".$formatter);
      
      return $output;
    }
    //table begin
    else if ($thing == "#||")
    {
      $this->br = 0;
      $this->cols = 0;
      $this->intablebr = true;
      return "<table class=\"dtable\" border=\"0\">";
    }
    //table end
    else if ($thing == "||#")
    {
      $this->br = 0;
      $this->intablebr = false;
      return "</table>";
    }
    else if ($thing == "#|")
    {
      $this->br = 0;
      $this->cols = 0;
      $this->intablebr = true;
      return "<table class=\"usertable\" border=\"1\">";
    }
    //table end
    else if ($thing == "|#")
    {
      $this->br = 0;
      $this->intablebr = false;
      return "</table>";
    }
    //
    else if (preg_match("/^\|\|(.*?)\|\|$/s", $thing, $matches))
    {
      $this->br = 1;
      $this->intable = true;
      $this->intablebr = false;
      

      $output = "<tr class=\"userrow\">";
      $cells = split("\|", $matches[1]);
      $count = count($cells);
      $count--;
      
      for ($i=0; $i<$count;$i++)
      {
        $this->tdoldIndentLevel = 0;
        $this->tdindentClosers = array();
        if ($cells[$i]{0}=="\n") $cells[$i] = substr($cells[$i], 1);
        $output .= str_replace("\177","",str_replace("\177"."<br />\n","","<td class=\"usercell\">".preg_replace_callback($this->LONGREGEXP, $callback, "\177\n".$cells[$i])));
        $output .= $this->indentClose();                                                   
        $output .= "</td>";
      }
      if (($this->cols <> 0) and ($count<$this->cols))
      {
        $this->tdoldIndentLevel = 0;
        $this->tdindentClosers = array();
        if ($cells[$i]{0}=="\n") $cells[$count] = substr($cells[$count], 1);
        $output .= str_replace("\177","",str_replace("\177"."<br />\n","","<td class=\"usercell\" colspan=".($this->cols-$count+1).">".preg_replace_callback($this->LONGREGEXP, $callback, "\177\n".$cells[$count])));
        $output .= $this->indentClose();
        $output .= "</td>";
      }
      else
      { 
        $this->tdoldIndentLevel = 0;
        $this->tdindentClosers = array();
        if ($cells[$i]{0}=="\n") $cells[$count] = substr($cells[$count], 1);
        $output .= str_replace("\177","",str_replace("\177"."<br />\n","","<td  class=\"usercell\">".preg_replace_callback($this->LONGREGEXP, $callback, "\177\n".$cells[$count])));
        $output .= $this->indentClose();
        $output .= "</td>";
      }
      $output .= "</tr>";
      
      if ($this->cols == 0)
      {
        $this->cols = $count;
      }
      $this->intablebr = true;
      $this->intable = false;
      return $output;
    }
    // Deleted 
    else if (preg_match("/^\xA4\xA4((\S.*?\S)|(\S))\xA4\xA4$/s", $thing, $matches))
    {
      $this->br = 0;
      return "<span class=\"del\">".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</span>";
    }
    // Inserted
    else if (preg_match("/^\xA3\xA3((\S.*?\S)|(\S))\xA3\xA3$/s", $thing, $matches))
    {
      $this->br = 0;
      return "<span class=\"add\">".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</span>";
    }
    // bold
    else if (preg_match("/^\*\*(.*?)\*\*$/", $thing, $matches))
    {
      return "<strong>".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</strong>";
    }
    // italic
    else if (preg_match("/^\/\/(.*?)\/\/$/", $thing, $matches))
    {
      return "<em>".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</em>";
    }
    // underlinue
    else if (preg_match("/^__(.*?)__$/", $thing, $matches))
    {
      return "<u>".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</u>";
    }
    // monospace
    else if (preg_match("/^\#\#(.*?)\#\#$/", $thing, $matches))
    {
      return "<tt>".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</tt>";
    }
    // small
    else if (preg_match("/^\+\+(.*?)\+\+$/", $thing, $matches))
    {
      return "<small>".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</small>";
    }
    // cite
    else if (preg_match("/^\'\'(.*?)\'\'$/s", $thing, $matches) ||
    preg_match("/^\!\!((\S.*?\S)|(\S))\!\!$/s", $thing, $matches))
    {
      $this->br = 1;
      return "<span class=\"cite\">".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</span>";
    }
    else if (preg_match("/^\?\?((\S.*?\S)|(\S))\?\?$/s", $thing, $matches))
    {
      $this->br = 1;
      return "<span class=\"mark\">".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</span>";
    }
    // urls
    else if (preg_match("/^([[:alpha:]]+:\/\/\S+?|mailto\:[[:alnum:]\-\_\.]+\@[[:alnum:]\-\.\_]+?)([^[:alnum:]^\/\-\_\=]?)$/", $thing, $matches)) {
      $url = strtolower($matches[1]);
      if (substr($url,-4)==".jpg" || substr($url,-4)==".gif" || substr($url,-4)==".png" || substr($url,-4)==".jpe"
      || substr($url,-5)==".jpeg") return "<img src=\"".$matches[1]."\" />".$matches[2];
      else return $wacko->PreLink($matches[1]).$matches[2];
    }
    // lan path
    else if (preg_match("/^(\\\\[".ALPHANUM_P."\\\!\.\-\_]+)$/", $thing, $matches)) {//[[:alnum:]\\\!\.\_\-]+\\
      return "<a href=\"".$matches[1]."\">".$matches[1]."</a>";
    }
    // centered
    else if (preg_match("/^>>(.*)<<$/s", $thing, $matches))
    {
      $this->br = 0;
      return "<div class=\"center\">".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</div>";
    }
    // blockquote
    else if (preg_match("/^<\[(.*)\]>$/s", $thing, $matches))
    {
      //$this->br = 0;
      return "<blockquote>".preg_replace_callback($this->LONGREGEXP, $callback, trim($matches[1]," \n\r\t"))."</blockquote>";
    }
    // super
    else if (preg_match("/^\^\^(.*)\^\^$/", $thing, $matches))
    {
      return "<sup>".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</sup>";
    }
    // sub
    else if (preg_match("/^vv(.*)vv$/", $thing, $matches))
    {
      return "<sub>".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</sub>";
    }
    // headers
    else if (preg_match("/\n[ \t]*=======(.*)=======$/", $thing, $matches))
    {
      $result = $this->indentClose();
      $this->br = 0; $wacko->headerCount++;
      return $result."<a name=\"h".$this->page_id."-".$wacko->headerCount."\"></a><h6>".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</h6>";
    }
    else if (preg_match("/\n[ \t]*======(.*)======$/", $thing, $matches))
    {
      $result = $this->indentClose();
      $this->br = 0; $wacko->headerCount++;
      return $result."<a name=\"h".$this->page_id."-".$wacko->headerCount."\"></a><h5>".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</h5>";
    }
    else if (preg_match("/\n[ \t]*=====(.*)=====$/", $thing, $matches))
    {
      $result = $this->indentClose();
      $this->br = 0; $wacko->headerCount++;
      return $result."<a name=\"h".$this->page_id."-".$wacko->headerCount."\"></a><h4>".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</h4>";
    }
    else if (preg_match("/\n[ \t]*====(.*)====$/", $thing, $matches))
    {
      $result = $this->indentClose();
      $this->br = 0; $wacko->headerCount++;
      return $result."<a name=\"h".$this->page_id."-".$wacko->headerCount."\"></a><h3>".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</h3>";
    }
    else if (preg_match("/\n[ \t]*===(.*)===$/", $thing, $matches))
    {
      $result = $this->indentClose();
      $this->br = 0; $wacko->headerCount++;
      return $result."<a name=\"h".$this->page_id."-".$wacko->headerCount."\"></a><h2>".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</h2>";
    }
    else if (preg_match("/\n[ \t]*==(.*)==$/", $thing, $matches))
    {
      $result = $this->indentClose();
      $this->br = 0; $wacko->headerCount++;
      return $result."<a name=\"h".$this->page_id."-".$wacko->headerCount."\"></a><h1>".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</h1>";
    }
    // separators
    else if (preg_match("/^[-]{4,}$/", $thing))
    {
      $this->br = 0;
      return "<hr noshade=\"noshade\" size=\"1\" />";
    }
    // forced line breaks
    else if (preg_match("/^---\n?\s*$/", $thing, $matches))
    {
      return "<br />\n";
    }
    // strike
    else if (preg_match("/^--((\S.*?\S)|(\S))--$/s", $thing, $matches))    //NB: wrong
    {
      return "<s>".preg_replace_callback($this->LONGREGEXP, $callback, $matches[1])."</s>";
    }
    // forced links ((link link == desc desc))
    else if ((preg_match("/^\[\[(.+)(==|\|)(.*)\]\]$/", $thing, $matches)) || 
             (preg_match("/^\(\((.+)(==|\|)(.*)\)\)$/", $thing, $matches)) )
    {
      list (, $url, ,$text) = $matches;
      if ($url)
      {
        if ($url!=($url=(preg_replace("/\xA4\xA4|__||\[\[|\(\(/","",$url)))) $result="</span>";
        if ($text == "") $text = $url;
        $url = str_replace( " ", "", $url );
        $text=preg_replace("/\xA4\xA4|__|\[\[|\(\(/","",$text);
        return $result.$wacko->PreLink($url, $text);
      }
      else
      {
        return "";
      }
    }
    // forced links
    else if ((preg_match("/^\[\[(\S+)(\s+(.+))?\]\]$/", $thing, $matches)) ||
             (preg_match("/^\(\((\S+)(\s+(.+))?\)\)$/", $thing, $matches)))
    {
      list (, $url, , $text) = $matches;
      if ($url)
      {
        if ($url!=($url=(preg_replace("/\xA4\xA4|\xA3\xA3|\[\[|\(\(/","",$url)))) $result="</span>";
        if (!$text) $text = $url;
        $text=preg_replace("/\xA4\xA4|\xA3\xA3|\[\[|\(\(/","",$text);
        return $result.$wacko->PreLink($url, $text);
      }
      else
      {
        return "";
      }
    }
    // indented text
  else if (preg_match("/(\n)(\t+|(?:[ ]{2})+)(-|\*|([0-9,a-z,A-Z]{1,2})[\.\)](\#[0-9]{1,3})?)?(\n|$)/s", $thing, $matches))
    {
      // new line
      $result .= ($this->br ? "<br />\n" : "\n");
      //intable or not?
      if ($this->intable) 
      {
       $Closers = &$this->tdindentClosers;
       $oldlevel = &$this->tdoldIndentLevel;
      }
      else
      {
       $Closers = &$this->indentClosers;
       $oldlevel = &$this->oldIndentLevel;
      }

      // we definitely want no line break in this one.
      $this->br = 0;

      //#18 syntax support
      if ($matches[5])
       $start = substr($matches[5], 1);
      else
       $start = "";

      // find out which indent type we want
      $newIndentType = $matches[3][0];
      if (!$newIndentType) { $opener = "<div class=\"indent\">"; $closer = "</div>"; $this->br = 1; }
      else if ($newIndentType == "-" || $newIndentType == "*") { $opener = "<ul><li>"; $closer = "</li></ul>"; $li = 1; }
      else { $opener = "<ol type=\"".$newIndentType."\"><li".($start?" value=\"".$start."\"":"").">"; $closer = "</li></ol>"; $li = 1; }

      // get new indent level
      if ($matches[2][0]==" ") 
       $newIndentLevel = (int) (strlen($matches[2])/2);
      else 
      $newIndentLevel = strlen($matches[2]);
      if ($newIndentLevel > $oldlevel)
      {
        for ($i = 0; $i < $newIndentLevel - $oldlevel; $i++)
        {
          $result .= $opener;
          array_push($Closers, $closer);
        }
      }
      else if ($newIndentLevel < $oldlevel)
      {
        for ($i = 0; $i < $oldlevel - $newIndentLevel; $i++)
        {
          $result .= array_pop($Closers);
        }
      }

      $oldlevel = $newIndentLevel;

      if ($li && !preg_match("/".str_replace(")", "\)", $opener)."$/", $result))
      {
        $result .= "</li><li".($start?" value=\"".$start."\"":"").">";
      }

      return $result;
    }
    // new lines
    else if ($thing == "\n" && !$this->intablebr)
    {
      // if we got here, there was no tab in the next line; this means that we can close all open indents.
      $result = $this->indentClose();
      if ($result) $this->br = 0;

      $result .= $this->br ? "<br />\n" : "\n";
      $this->br = 1;
      return $result;
    }
    // interwiki links
    else if (preg_match("/^([[:alnum:]]+[:]".ALPHANUM."[".ALPHANUM_P."\-\_\.\+\&\=]+?)([^[:alnum:]^\/\-\_\=]?)$/s", $thing, $matches))
    {
      return $wacko->PreLink($matches[1]).$matches[2];
    }
    // tikiwiki links
    else if ((!$wacko->_formatter_noautolinks) && $wacko->GetConfigValue("disable_tikilinks")!=1 &&
             (preg_match("/^(".UPPER.LOWER.ALPHANUM."*\.".ALPHA.ALPHANUM."+)$/s", $thing, $matches)))
    {
      return $wacko->PreLink($thing);
    }
    // npj links
    else if ((!$wacko->_formatter_noautolinks) &&
             (preg_match("/^(~?)(".ALPHANUM_L."+\@".ALPHA_L."*(\:".ALPHANUM."*)?|".ALPHANUM_L."+\:\:".ALPHANUM."+)$/s", $thing, $matches)))
    {
      if ($matches[1]=="~")
       return $matches[2];
      return $wacko->PreLink($thing); 
    }
    // wacko links!
    else if ((!$wacko->_formatter_noautolinks) &&
             (preg_match("/^(((\.\.)|!)?\/?|~)?(".UPPER.LOWER."+".UPPERNUM.ALPHANUM."*)$/s", $thing, $matches)))
    {
      if ($matches[1]=="~")
       return $matches[4];
      return $wacko->PreLink($thing); 
    }
    if (($thing[0] == "~") && ($thing[1] != "~")) $thing=ltrim($thing, "~");
    if (($thing[0] == "~") && ($thing[1] == "~")) return "~".preg_replace_callback($this->LONGREGEXP, $callback, substr($thing,2));
    // if we reach this point, it must have been an accident.
    return htmlspecialchars($thing);
  }
}

?>