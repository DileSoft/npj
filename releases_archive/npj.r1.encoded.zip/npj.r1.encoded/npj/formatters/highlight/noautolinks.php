<?php

$object->_formatter_noautolinks = true;
//print($this->Format($text, "wacko"));
include($rh->formatters_dir."wacko.php");
$object->_formatter_noautolinks = false;


?>
