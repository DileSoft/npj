<?php

$rh->UseClass("DelphiHightlighter", $rh->formatters_classes_dir);

$DH = &new DelphiHightlighter();
echo "<pre>".$DH->analysecode($text)."</pre>";
unset($DH);

?>