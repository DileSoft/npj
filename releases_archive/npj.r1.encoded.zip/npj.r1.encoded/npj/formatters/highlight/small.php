<?php
print("<small>".$text."</small>");
?>