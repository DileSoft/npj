<?php

  $rh->UseClass("ListSimple", $rh->core_dir);
  $rh->UseClass("Form"      , $rh->core_dir);
  $rh->UseClass("Field"     , $rh->core_dir);
  $rh->UseClass("FieldString" , $rh->core_dir);
  $rh->UseClass("FieldRadio"  , $rh->core_dir);
  $rh->UseClass("ButtonList"  , $rh->core_dir);
  $rh->UseClass("FieldMultiple" , $rh->core_dir);

  ///////////////////////////

  {
     $rs = $db->Execute( "select group_id from ".$rh->db_prefix."groups where is_system=1 and group_rank=".GROUPS_SELF." and user_id=".
                         $db->Quote( $rh->account->data["user_id"] ) );
     $rh->account->group_nobody = 1*$rs->fields["group_id"];
     $rs = $db->Execute( "select group_id from ".$rh->db_prefix."groups where is_system=1 and group_rank=".GROUPS_FRIENDS." and user_id=".
                         $db->Quote( $rh->account->data["user_id"] ) );
     $rh->account->group_friends = 1*$rs->fields["group_id"];
     $rs = $db->Execute( "select group_id from ".$rh->db_prefix."groups where is_system=1 and group_rank=".GROUPS_COMMUNITIES." and user_id=".
                         $db->Quote( $rh->account->data["user_id"] ) );
     $rh->account->group_communities = 1*$rs->fields["group_id"];

    $group3 = array();
    $rs = $db->Execute("SELECT group_id, group_name FROM ".$rh->db_prefix."groups WHERE user_id=".$db->Quote($rh->account->data["user_id"])
    ." and group_rank=".GROUPS_FRIENDS." and is_system=0;"); $a=$rs->GetArray();
    $data4form=array(); $seldata4form=array();
    if (sizeof($a)==0) ; // ???refactor -- ����� ���������� ��������� ��������� ������ ��������� 
    else foreach ($a as $item) $data4form[$item["group_id"]]=$item["group_name"];
    if (!$is_new) 
    if ($this->data["group1"] == 0) $seldata4form=-1;
    else
    if ($this->data["group1"] == $rh->account->group_nobody) $seldata4form=0;
    else
    if ($this->data["group1"] == $rh->account->group_friends) $seldata4form=-2;
    else
    if ($this->data["group1"] == $rh->account->group_communities) $seldata4form=-3;
    else
    {
     if ($this->data["group1"]) $seldata4form[] = $this->data["group1"];
     if ($this->data["group2"]) $seldata4form[] = $this->data["group2"];
     if ($this->data["group3"]) $seldata4form[] = $this->data["group3"];
     if ($this->data["group4"]) $seldata4form[] = $this->data["group4"];
    }
    if (sizeof($seldata4form) == 0) $seldata4form = -1;
    $group3[] = &new FieldMultiple( &$rh, array(
                          "field" => "groups",
                          "maxsize" => 4,
                          "data_plain" => 1,
                          "default" => $seldata4form,
                          "data" => $data4form,
                          "db_ignore" => 1,
                           ) ); 
  }

  ///////////////////////////
      $form_config = array(
      "db_table"    => $rh->db_prefix."records", 
      "db_id"       => "record_id",
      "message_set" => $rh->message_set."_form_RecordGroups",
        );
      $form_buttons = array(
          array( "name" => $tpl->message_set["ButtonTextUpdate"],  
                 "tpl_name" => "forms/buttons.html:Update", "handler" => "_nothing", "default"=>1 )
          );
      $form_buttons[] = 
          array( "name" => $tpl->message_set["ButtonTextCancel"],  
                 "tpl_name" => "forms/buttons.html:Cancel", "handler" => "_cancel", "default"=>1 );

      $form_fields = array(  &$group3, );

    $form = &new Form( &$rh, &$form_config, &$form_fields, &$form_buttons );

  ///////////////////////////




?>