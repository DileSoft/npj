<?php

  if ($state->Get("confirm") !="record_delete_granted")
  {
  $data = &$this->Load( 2 );
   if ($this->GetType() == RECORD_DOCUMENT)
     if (!$this->HasAccess( &$principal, "acl", "remove" )) return $this->Forbidden("RecordForbiddenDelete"); 
   else
     if (!$this->HasAccess( &$principal, "owner" )) return $this->Forbidden("RecordForbiddenDelete"); 
  }
  else
  {
    $tpl->Assign("404", "record deleted");
  }

  // �������� �� �������
  if (!$rh->account->HasAccess( &$principal, "not_acl", "banlist" )) return $this->Forbidden("YouAreInBanlist");

  $rh->UseClass("ConfirmForm", $rh->core_dir);
  $confirm = &new ConfirmForm( &$rh, "record_delete", $rh->message_set."_confirm_record_delete" );
  
  $result = $confirm->Handle();
  if ($result === false) $result = $confirm->ParseConfirm();
  
  $tpl->Assign("Preparsed:CONTENT", $result);

  return GRANTED;

?>